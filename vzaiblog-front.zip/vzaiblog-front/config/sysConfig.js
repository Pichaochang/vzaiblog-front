const sysConfig = {
  baseUrl: 'https://www.zhangbizhao.xyz/'
};
export default sysConfig;